#import socket module
import socket

host='localhost'
server_port=8500

# creating the server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# binding the socket to the give port
server_socket.bind((host,server_port))

# waiting for the connection
server_socket.listen(1)

print ('the web server is up on port:',server_port)

while True:  
  
    print ('Ready to serve...')
  
    # accepting the incoming client connection
    connection, address = server_socket.accept()

    try:
      
        # getting the request message from the client
        message = connection.recv(1024)
      
        # getting file name from the message
        filename = message.split()[1]
      
        # opening the file  
        f = open(filename[1:])
      
        # getting the file contents
        outputdata = f.read()      
      
        #Send one HTTP header line into socket      
        connection.send('\nHTTP/1.1 200 OK\n\n'.encode())
              
        #Send the content of the requested file to the client
        for i in range(0, len(outputdata)):
            connection.send(outputdata[i].encode())
      
        # closing the client connection
        connection.close()
  
    except IOError:
      
        #Send response message for file not found      
        connection.send('\nHTTP/1.1 404 Not Found\n\n'.encode())
        connection.send('<html><body><center><h3>Error 404: File not found</h3></center></body></html>'.encode())
      
        # closing the client connection
        connection.close()
      
#closing the server socket   
server_socket.close()